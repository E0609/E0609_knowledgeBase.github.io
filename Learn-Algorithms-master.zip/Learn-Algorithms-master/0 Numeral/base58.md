# base58

btc中 base58编码表是

```
123456789 abcdefg hijk mn opqrst uvwxyz ABCDEFG HJ KLMN PQRST UVWXYZ
```


相比 base64 去掉了 6个字符，  数字0， 大写字母 O,  大写字母 I (小写i) ， 小写字母 l (大写L)， 以及 + 和 / 



### 编码实现

```

```


