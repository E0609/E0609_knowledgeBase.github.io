// FROM:http://www.gowrikumar.com/c/
 #include <stdio.h>
  int main()
  {
   float a = 12.5;
   printf("%d\n", a);
   //printf("%d\n", *(int *)&a);
   return 0;
  }

// 浮点数 转 整形 ,用强制转换(int)a

/*
浮点数的存储

*/  
