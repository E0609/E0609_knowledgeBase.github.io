

#include "stdio.h"


/*

	1 是第一个元素
	序列中元素被2或3或5整除

*/
unsigned long value_in_sequence(unsigned index){

	


}


int main(){



	return 0;
}