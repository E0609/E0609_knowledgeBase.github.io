#include <stdio.h>
  int main()
  {
      int n;
      printf("Enter a number:\n");
      scanf("%d",&n); // &

      printf("You entered %d \n",n);
      return 0;
  }