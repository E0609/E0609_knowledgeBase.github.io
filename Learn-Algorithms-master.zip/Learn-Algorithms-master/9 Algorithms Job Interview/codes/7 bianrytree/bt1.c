
/*
二叉查找树变成双向链表
*/

typedef struct BSTreeNode{
	int m_nValue;
	struct BSTreeNode *m_pLeft, *m_pRight;
}BSTree;

void convertDoubleLinks(BSTree *root){


}


int main(int argc, char const *argv[])
{
	
	return 0;
}




