
#include <stdio.h>

int main()
{
        int a = (1,2);
        printf("a : %d\n",a);
        return 0;
}

// ，运算符优先级 最低 ,括号不能少
// 

