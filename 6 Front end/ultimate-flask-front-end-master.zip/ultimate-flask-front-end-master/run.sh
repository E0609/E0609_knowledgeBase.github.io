#!/bin/bash

python project/app.py