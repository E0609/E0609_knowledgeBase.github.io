Be sure to check out the blog posts-

1. https://realpython.com/blog/python/the-ultimate-flask-front-end/
1. https://realpython.com/blog/python/the-ultimate-flask-front-end-part-2/