/* (C) 2005 by Frank McCown
 * You may modify or use this code in any way you would like. 
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp; 

namespace guiexample
{
	/// <summary>
	/// Summary description for Server.
	/// </summary>
	public class Server : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Label lblHello;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txbRespond;

		private Greeter rmGreeter;   // Remote object to instantiate here
		private delegate void SetLabelTextDelegate(string text);   // For updating label
		

		public Server()
		{
			// Required for Windows Form Designer support
			InitializeComponent();

			// Register our tcp channel
			ChannelServices.RegisterChannel(new TcpChannel(50050));

			// Register an object created by the server
			rmGreeter = new Greeter();
			ObjRef refGreeter = RemotingServices.Marshal(rmGreeter, "Greeter");

			rmGreeter.RespondTime = Convert.ToInt32(txbRespond.Text);

			// Register ourself to receive updates that we will display in our GUI
			rmGreeter.HelloEvent += new Greeter.HelloEventHandler(Server_HelloEvent);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblHello = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.txbRespond = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lblHello
			// 
			this.lblHello.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblHello.Location = new System.Drawing.Point(8, 16);
			this.lblHello.Name = "lblHello";
			this.lblHello.Size = new System.Drawing.Size(248, 56);
			this.lblHello.TabIndex = 0;
			this.lblHello.Text = "Waiting for clients...";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 80);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(136, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Time to respond (msec):";
			// 
			// txbRespond
			// 
			this.txbRespond.Location = new System.Drawing.Point(128, 80);
			this.txbRespond.Name = "txbRespond";
			this.txbRespond.Size = new System.Drawing.Size(64, 20);
			this.txbRespond.TabIndex = 2;
			this.txbRespond.Text = "2000";
			this.txbRespond.TextChanged += new System.EventHandler(this.txbRespond_TextChanged);
			// 
			// Server
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(272, 108);
			this.Controls.Add(this.txbRespond);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lblHello);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.Name = "Server";
			this.Text = "Server";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Server());
		}

		private void SetLabelText(string text)
		{
			lblHello.Text = text;
		}

		// Called when the Greeter object tells us SayHello has been called
		private void Server_HelloEvent(object sender, HelloEventArgs e)
		{
			// Get name from the event
			string text = "Saying hello to " + e.Name;

			// Set the label text with the UI thread to avoid possible application hanging
			this.BeginInvoke(new SetLabelTextDelegate(SetLabelText), new object[] {text});	
		}

		private void txbRespond_TextChanged(object sender, System.EventArgs e)
		{
			try
			{
				// Set delay before we respond to the client

				int delay = Convert.ToInt32(txbRespond.Text);
				if (delay >= 0)
					rmGreeter.RespondTime = delay;
			}
			catch (Exception) {}
		}		
	}
}
