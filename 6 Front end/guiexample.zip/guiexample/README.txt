Remoting with GUIs
by Frank McCown
fmccown@harding.edu


RUNNING
-------

Run the Server by running server.exe
Run the Clinet by running client.exe


COMPILING
---------

In order to re-build the client.exe and server.exe files, just type make at the command line.
This will run make.bat which compiles the files using the csc compiler.

