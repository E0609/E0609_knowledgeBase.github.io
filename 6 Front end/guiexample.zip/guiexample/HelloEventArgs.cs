/* (C) 2005 by Frank McCown
 * You may modify or use this code in any way you would like. 
 */

using System;

namespace guiexample
{
	public class HelloEventArgs : EventArgs 
	{
		private string mName;
		public string Name
		{
			get { return mName; }
		}

		public HelloEventArgs(string name)
		{
			mName = name;
		}
	}
}
