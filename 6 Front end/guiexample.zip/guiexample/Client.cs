/* (C) 2005 by Frank McCown
 * You may modify or use this code in any way you would like. 
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Runtime.Remoting.Messaging;  // for asynchronous callbacks

namespace guiexample
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Client : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label lblSayHello;
		private System.Windows.Forms.TextBox txbName;
		private System.Windows.Forms.Label lblResult;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnCallSynch;
		private System.Windows.Forms.Button btnCallAsynch;

		private Greeter rmGreeter;   // Our remote object
        private delegate void SetLabelTextDelegate(string text);   // For updating label
		private delegate string SayHelloDelegate(string name);     // For asynch callback

		public Client()
		{
			// Required for Windows Form Designer support
			InitializeComponent();

			// Register our tcp channel
			ChannelServices.RegisterChannel(new TcpChannel());

			rmGreeter = (Greeter)Activator.GetObject(
				typeof(guiexample.Greeter),	"tcp://localhost:50050/Greeter");

			lblResult.Text = "";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblSayHello = new System.Windows.Forms.Label();
			this.txbName = new System.Windows.Forms.TextBox();
			this.btnCallSynch = new System.Windows.Forms.Button();
			this.btnCallAsynch = new System.Windows.Forms.Button();
			this.lblResult = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// lblSayHello
			// 
			this.lblSayHello.Location = new System.Drawing.Point(24, 16);
			this.lblSayHello.Name = "lblSayHello";
			this.lblSayHello.Size = new System.Drawing.Size(144, 16);
			this.lblSayHello.TabIndex = 0;
			this.lblSayHello.Text = "Say hello to:";
			// 
			// txbName
			// 
			this.txbName.Location = new System.Drawing.Point(24, 40);
			this.txbName.Name = "txbName";
			this.txbName.Size = new System.Drawing.Size(136, 20);
			this.txbName.TabIndex = 1;
			this.txbName.Text = "";
			// 
			// btnCallSynch
			// 
			this.btnCallSynch.Location = new System.Drawing.Point(24, 112);
			this.btnCallSynch.Name = "btnCallSynch";
			this.btnCallSynch.Size = new System.Drawing.Size(136, 23);
			this.btnCallSynch.TabIndex = 2;
			this.btnCallSynch.Text = "Call Synchronously";
			this.btnCallSynch.Click += new System.EventHandler(this.btnCallSynch_Click);
			// 
			// btnCallAsynch
			// 
			this.btnCallAsynch.Location = new System.Drawing.Point(24, 144);
			this.btnCallAsynch.Name = "btnCallAsynch";
			this.btnCallAsynch.Size = new System.Drawing.Size(136, 23);
			this.btnCallAsynch.TabIndex = 3;
			this.btnCallAsynch.Text = "Call Asynchronously";
			this.btnCallAsynch.Click += new System.EventHandler(this.btnCallAsynch_Click);
			// 
			// lblResult
			// 
			this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblResult.Location = new System.Drawing.Point(24, 72);
			this.lblResult.Name = "lblResult";
			this.lblResult.Size = new System.Drawing.Size(160, 16);
			this.lblResult.TabIndex = 5;
			this.lblResult.Text = "label2";
			// 
			// Client
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(182, 180);
			this.Controls.Add(this.lblResult);
			this.Controls.Add(this.btnCallAsynch);
			this.Controls.Add(this.btnCallSynch);
			this.Controls.Add(this.txbName);
			this.Controls.Add(this.lblSayHello);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.MaximizeBox = false;
			this.Name = "Client";
			this.Text = "Client";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Client());
		}

		private void btnCallSynch_Click(object sender, System.EventArgs e)
		{
			lblResult.Text = "";

			// Force update since the remote method call blocks us from receiving window messages
			lblResult.Refresh();   

			try
			{
				lblResult.Text = rmGreeter.SayHello(txbName.Text);
			}
			catch (Exception ex)
			{
				ShowError("Unable to call SayHello.  Make sure the server is running.\n" + ex.Message);
			}
		}

		private void SetLabelText(string text)
		{
			lblResult.Text = text;
		}

		// Called when the remote method SayHello completes
		public void SayHelloCallBack(IAsyncResult ar)
		{
			SayHelloDelegate d = (SayHelloDelegate)((AsyncResult)ar).AsyncDelegate;
				
			try
			{
				// Pull out the return value
				string text = (string)d.EndInvoke(ar);

				// Set the label text with the UI thread to avoid possible application hanging
				this.BeginInvoke(new SetLabelTextDelegate(SetLabelText), new object[] {text});				 
			}
			catch (Exception ex)
			{
				ShowError("Unable to call SayHello.  Make sure the server is running.\n" + ex.Message);
			}
		}

		private void btnCallAsynch_Click(object sender, System.EventArgs e)
		{
			lblResult.Text = "";

			// Produce an asynchronous call to the remote method SayHello from which
			// we'll immediately return

			AsyncCallback cb = new AsyncCallback(this.SayHelloCallBack);
			SayHelloDelegate d = new SayHelloDelegate(rmGreeter.SayHello);
			IAsyncResult ar = d.BeginInvoke(txbName.Text, cb, null);
		}

		private void ShowError(string msg)
		{
			MessageBox.Show(this, msg, "Client", MessageBoxButtons.OK, MessageBoxIcon.Error);
		}
	}

}
